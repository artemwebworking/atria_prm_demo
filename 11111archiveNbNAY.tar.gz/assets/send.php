<?php 
	$phone = $_POST['phone'];
	$email = $_POST['email'];
	$name = $_POST['name'];
	$token = "6898106487:AAFibnm3XH4E22dZHzNWBWP8KRQnMWyFYr4";
	$chat_id = "-1002126500963";
	$arr = array(
		'Телефон: ' => $phone,
		'Email: ' => $email,
		'Имя пользователя: ' => $name
	);

	foreach($arr as $key => $value) {
		$txt .= "<b>".$key."</b>".$value."%0A";
	};

	$sendToTelegram = fopen("https://api.telegram.org/bot{$token}/sendMessage?chat_id={$chat_id}&parse_mode=html&text={$txt}","r");

?>