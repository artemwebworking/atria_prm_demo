function formTesting() {
    let emailWrapper = document.querySelector('.email-wrapper');
    let phoneWrapper = document.querySelector('.phone-wrapper');
    let nameWrapper = document.querySelector('.name-wrapper');
    let emailAnswer = document.querySelector('.email-answer');
    let phoneAnswer = document.querySelector('.phone-answer');
    let nameAnswer = document.querySelector('.name-answer');
    let successBlock = document.querySelector('.opening-popup');

    $('#form').submit(function (event) {
        event.preventDefault();
        let emailInputValue = document.getElementById('email-input').value;
        let phoneInputValue = document.getElementById('phone-input').value;
        let nameInputValue = document.getElementById('name-input').value;

        let isValid = true;

        if (!validateEmail(emailInputValue)) {
            emailWrapper.classList.add('error');
            emailAnswer.classList.add('active');
            emailAnswer.innerHTML = 'Ведіть Ваше пошту';
            isValid = false;
        } else {
            emailWrapper.classList.remove('error');
            emailAnswer.classList.remove('active');
        }

        if (!validatePhone(phoneInputValue)) {
            phoneWrapper.classList.add('error');
            phoneAnswer.classList.add('active');
            phoneAnswer.innerHTML = 'Ведіть Ваше номер';
            isValid = false;
        } else {
            phoneWrapper.classList.remove('error');
            phoneAnswer.classList.remove('active');
        }

        if (!validateName(nameInputValue)) {
            nameWrapper.classList.add('error');
            nameAnswer.classList.add('active');
            nameAnswer.innerHTML = "Ведіть Ваше ім'я";
            isValid = false;
        } else {
            nameWrapper.classList.remove('error');
            nameAnswer.classList.remove('active');
        }

        if (!isValid) return;

        var form_data = $(this).serialize();
        $.ajax({
            type: 'POST',
            url: 'sendTesting.php',
            data: form_data,
            success: function (data) {
                successBlock.classList.add('success');
                $('#form')[0].reset();  // Очистить форму после отправки
            },
            error: function (data) {
                emailAnswer.classList.add('active');
                emailAnswer.innerHTML = 'Error';
            }
        });
    });

    let emailInput = document.getElementById('email-input');
    emailInput.addEventListener('input', () => {
        emailAnswer.classList.remove('active');
        emailWrapper.classList.remove('error');
    });

    let phoneInput = document.getElementById('phone-input');
    phoneInput.addEventListener('input', () => {
        phoneAnswer.classList.remove('active');
        phoneWrapper.classList.remove('error');
    });

    let nameInput = document.getElementById('name-input');
    nameInput.addEventListener('input', () => {
        nameAnswer.classList.remove('active');
        nameWrapper.classList.remove('error');
    });

    function validateEmail(email) {
        const re = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
        return re.test(email);
    }

    function validatePhone(phone) {
        const re = /^[0-9()+\-\s]*$/;
        return phone ? re.test(phone) : false;
    }

    function validateName(name) {
        const re = /^.{1,15}$/; // от 1 до 15 символов
        return re.test(name);
    }
}

export { formTesting };
