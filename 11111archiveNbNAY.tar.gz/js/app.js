import $ from 'jquery'
window.jQuery = $
window.$ = $
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import { Draggable } from 'gsap/Draggable';
import { formTesting } from './assets/formTesting';
import MotionPathPlugin from 'gsap/MotionPathPlugin'

window.jQuery = $;
window.$ = $;

import Swiper from 'swiper/bundle';
import 'swiper/css/bundle';

gsap.registerPlugin(MotionPathPlugin) 
gsap.registerPlugin(ScrollTrigger);
gsap.registerPlugin(Draggable);

document.addEventListener('DOMContentLoaded', () => {
	
	function customMarquee() {
		let marqueeElements = document.querySelectorAll('.marquee-item');
	
		// Проверка наличия элементов .marquee-item
		if (marqueeElements.length === 0) return;
	
		let totalWidth = 0;
		let animationDuration = 5 * marqueeElements.length;
	
		for (let i = 0; i < marqueeElements.length; i++) {
			let elementsWidth = marqueeElements[i].clientWidth;
			let xPosition = elementsWidth * (i + 1);
			totalWidth += elementsWidth;
	
			gsap.set(marqueeElements[i], {
				x: -totalWidth
			});
		}
	
		console.log(totalWidth);
		gsap.to('.marquee-item', {
			duration: animationDuration,
			ease: "none",
			x: `-=${totalWidth}`,
			modifiers: {
				x: gsap.utils.unitize(x => parseFloat(x) % -totalWidth)
			},
			repeat: -1
		});
	}


	function teamSelect() {
		const buttons = document.querySelectorAll('.team-main-persons-buttons-element');
        const images = document.querySelectorAll('.team-main-persons-window-img img');
        const names = document.querySelectorAll('.team-main-persons-window-name-element');

        buttons.forEach((button, index) => {
            button.addEventListener('click', () => {
                // Убираем класс "актив" у всех кнопок, изображений и имен
                buttons.forEach(btn => btn.classList.remove('active'));
                images.forEach(img => img.classList.remove('active'));
                names.forEach(name => name.classList.remove('active'));

                // Добавляем класс "актив" к текущему элементу
                button.classList.add('active');
                images[index].classList.add('active');
                names[index].classList.add('active');
            });
        });
	}

	const swiperThreeElement = document.querySelector('.swiper-03');
	if (swiperThreeElement) {
	const swiperThree = new Swiper('.swiper-03', {
		direction: 'horizontal',
		loop: false,
		slidesPerView: 1,
		spaceBetween: 4,
		slidesPerGroup: 1,
		navigation: {
		nextEl: '.swiper-button-next',
		prevEl: '.swiper-button-prev',
		},
		pagination: {
			el: '.swiper-pagination',
			type: 'fraction',
			renderBullet: function (index, className) {
				// Форматирование номера слайда с ведущим нулём
				const formattedIndex = String(index + 1).padStart(2, '0');
				return '<span class="' + className + '">' + formattedIndex + '</span>';
			},
		},
		breakpoints: {
			769: {
			  slidesPerView: 4,
			  slidesPerGroup: 8,
			  spaceBetween: 4,
			},
		},
	});
  }

	function openingPopup() {
		const openingPopupButton = document.querySelectorAll('.form-trigger');
		const openingPopupForm = document.querySelector('.opening-popup');
		const openingPopupClose = document.querySelectorAll('.opening-popup-main-header-close.popup_form');
	  
		if (openingPopupForm) {
		  function closePopup() {
			openingPopupForm.classList.remove('active');
			if (openingPopupForm.classList.contains('success')) {
			  openingPopupForm.classList.remove('success');
			}
		  }
	  
		  openingPopupClose.forEach(closeButton => {
			closeButton.addEventListener('click', closePopup);
		  });
	  
		  if (openingPopupButton.length > 0) {
			openingPopupButton.forEach(button => {
			  button.addEventListener('click', () => {
				openingPopupForm.classList.add('active');
			  });
			});
		  }
		}
	  }

	  if (document.querySelector("#fly_el-pics") && document.querySelector("#fly_el-line")) {
		gsap.to("#fly_el-pics", {
			duration: 10, 
			repeat: -1,
			// repeatDelay: 1,
			ease: "power1.inOut",
			motionPath: {
				path: "#fly_el-line",
				align: "#fly_el-line",
				autoRotate: true,
				alignOrigin: [0.5, 0.5],
			}
		});
	}

	// inview animations
let inviewBodyText = document.querySelectorAll('.inview');

function inviewAnimations() {
    inviewBodyText.forEach(section => {
        ScrollTrigger.create({
            trigger: section,
            start: "top bottom-=100px",
            end: "bottom bottom",
            onEnter: () => {
                inview(section);
            },
            onLeaveBack: () => {
                outOfView(section);
            }
        });
    });
}

function inview(section) {
    if (section) {
        gsap.fromTo(section, {
            y: 30,
			opacity: 0,
        }, {
			y: 0,
            opacity: 1,
            stagger: .1,
            duration: .5,
            delay: .3,
		});
    }
}

function outOfView(section) {
    if (section) {
        gsap.to(section, {
            opacity: 0,
            duration: .5
        },
	);
    }
}

function mobileMenu() {
    let mobileMenuButton = document.querySelector('.header-main-burger');
    let mobileMenuBlock = document.querySelector('.mobile-menu');
    let mobileMenuClose = document.querySelector('.mobile-menu-close');

    if (mobileMenuButton && mobileMenuBlock && mobileMenuClose) {
      mobileMenuButton.addEventListener('click', () => {
        mobileMenuBlock.classList.add('active');
      });

      mobileMenuClose.addEventListener('click', () => {
        mobileMenuBlock.classList.remove('active');
      });
    }
  }


  function classifiersDropdown() {
    const dropdowns = document.querySelectorAll('.classifiers-dropdown');

    if (dropdowns.length > 0) {
        dropdowns.forEach(dropdown => {
            dropdown.addEventListener('click', () => {
                // Найти родительский элемент с классом .classifiers-main-files-element
                const parentElement = dropdown.closest('.classifiers-main-files-element');

                if (parentElement) {
                    // Проверить, является ли родительский элемент уже активным
                    const isActive = parentElement.classList.contains('active');

                    // Удалить класс active у всех родительских элементов
                    document.querySelectorAll('.classifiers-main-files-element').forEach(element => {
                        element.classList.remove('active');
                    });

                    // Если родительский элемент не был активным, добавить класс active
                    if (!isActive) {
                        parentElement.classList.add('active');
                    }
                }
            });
        });
    }
}

function casePopupGallery() {
	// Проверяем наличие элемента .case-main-header-img-gallery
	const galleryTrigger = document.querySelector('.case-main-header-img-gallery');
	const galleryPopup = document.querySelector('.gallery-popup');
	const galleryClose = document.querySelector('.gallery-popup-close');
  
	// Если элемент .case-main-header-img-gallery существует
	if (galleryTrigger) {
	  galleryTrigger.addEventListener('click', () => {
		// Добавляем класс active к .gallery-popup
		if (galleryPopup) {
		  galleryPopup.classList.add('active');
		}
	  });
	}
  
	// Если элемент .gallery-popup-close существует
	if (galleryClose) {
	  galleryClose.addEventListener('click', () => {
		// Удаляем класс active у .gallery-popup
		if (galleryPopup) {
		  galleryPopup.classList.remove('active');
		}
	  });
	}
  
	// Закрытие попапа при клике вне его области
	document.addEventListener('click', (event) => {
	  if (galleryPopup && !galleryPopup.contains(event.target) && !galleryTrigger.contains(event.target)) {
		galleryPopup.classList.remove('active');
	  }
	});


	// atria scripts

	// function updateFileName(input) {
    //       const fileName =
    //         input.files.length > 0 ? input.files[0].name : "Файл не вибрано";
    //       document.getElementById("file-name").textContent = fileName;
    // }
}

 casePopupGallery()

	inviewAnimations()
	mobileMenu()
	openingPopup()
	teamSelect()
	customMarquee()
	formTesting()
	classifiersDropdown()
})
